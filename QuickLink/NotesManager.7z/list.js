document.addEventListener('DOMContentLoaded', function () {
    console.log('DOMContentLoaded event fired on list page');

    function fetchAllNotes() {
        const dbName = 'notesDB';
        const request = window.indexedDB.open(dbName);

        request.onerror = function(event) {
            console.error('IndexedDB error:', event.target.errorCode);
        };

        request.onsuccess = function(event) {
            console.log('Database connection opened successfully');
            const db = event.target.result;
            const transaction = db.transaction(['notesStore'], 'readonly');
            const objectStore = transaction.objectStore('notesStore');

            const getAllRequest = objectStore.getAll();

            getAllRequest.onsuccess = function(event) {
                const notes = event.target.result;
                displayNotes(notes);
            };

            getAllRequest.onerror = function(event) {
                console.error('Error fetching notes:', event.target.error);
            };
        };
    }

    function displayNotes(notes) {
        const notesList = document.getElementById('notesList');
        notesList.innerHTML = ''; // Clear previous content
        if (notes.length === 0) {
            notesList.textContent = 'No notes found.';
        } else {
            notes.forEach(note => {
                const noteDiv = document.createElement('div');
                noteDiv.className = 'note';
                noteDiv.textContent = `Keyword: ${note.keyword}, Text: ${note.text}`;
                notesList.appendChild(noteDiv);
            });
        }
    }

    function deleteAllNotes() {
        const dbName = 'notesDB';
        const request = window.indexedDB.open(dbName);

        request.onerror = function(event) {
            console.error('IndexedDB error:', event.target.errorCode);
        };

        request.onsuccess = function(event) {
            const db = event.target.result;
            const transaction = db.transaction(['notesStore'], 'readwrite');
            const objectStore = transaction.objectStore('notesStore');

            const clearRequest = objectStore.clear();

            clearRequest.onsuccess = function(event) {
                console.log('All notes deleted successfully');
                fetchAllNotes(); // Refresh the notes list
            };

            clearRequest.onerror = function(event) {
                console.error('Error deleting notes:', event.target.error);
            };
        };
    }

    const deleteAllButton = document.getElementById('deleteAllButton');
    deleteAllButton.addEventListener('click', function () {
        const confirmation = confirm('Are you sure you want to delete all notes? This action cannot be undone.');
        if (confirmation) {
            deleteAllNotes();
        }
    });

    const setKeywordButton = document.getElementById('setKeywordButton');
    setKeywordButton.addEventListener('click', function () {
        const newKeyword = document.getElementById('omniboxKeyword').value;
        if (newKeyword) {
            chrome.storage.sync.set({ omniboxKeyword: newKeyword }, function() {
                alert('Omnibox keyword set! The changes should take effect immediately.');
            });
        }
    });

    const setShortcutButton = document.getElementById('setShortcutButton');
    setShortcutButton.addEventListener('click', function () {
        const newShortcut = document.getElementById('shortcutInput').value;
        if (newShortcut) {
            chrome.commands.update({
                name: '_execute_action',
                shortcut: newShortcut
            }, function() {
                alert('Keyboard shortcut set!');
            });
        }
    });

    fetchAllNotes();
});
