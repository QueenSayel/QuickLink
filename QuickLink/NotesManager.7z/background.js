chrome.omnibox.onInputEntered.addListener((text) => {
    console.log('Omnibox input:', text);

    const dbName = 'notesDB';
    const request = indexedDB.open(dbName);

    request.onerror = function(event) {
        console.error('IndexedDB error:', event.target.errorCode);
    };

    request.onsuccess = function(event) {
        const db = event.target.result;
        const transaction = db.transaction(['notesStore'], 'readonly');
        const objectStore = transaction.objectStore('notesStore');
        const index = objectStore.index('keyword');

        const getRequest = index.get(text);

        getRequest.onsuccess = function(event) {
            const note = event.target.result;
            if (note) {
                if (note.isUrl) {
                    let url = note.text;
                    if (!isValidUrl(url)) {
                        url = 'http://' + url;
                    }
                    if (isValidUrl(url)) {
                        chrome.tabs.update({ url: url });
                    } else {
                        chrome.tabs.update({ url: 'chrome://newtab' });
                    }
                } else {
                    chrome.tabs.update({ url: 'chrome://newtab' });
                }
            } else {
                chrome.tabs.update({ url: 'chrome://newtab' });
            }
        };

        getRequest.onerror = function(event) {
            console.error('Error retrieving note:', event.target.error);
            chrome.tabs.update({ url: 'chrome://newtab' });
        };
    };
});

chrome.runtime.onInstalled.addListener(() => {
    chrome.storage.sync.get('omniboxKeyword', (data) => {
        if (!data.omniboxKeyword) {
            chrome.storage.sync.set({ omniboxKeyword: 'note' });
        }
    });
});

chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'sync' && changes.omniboxKeyword) {
        chrome.omnibox.setDefaultSuggestion({
            description: `Search Notes: ${changes.omniboxKeyword.newValue}`
        });
    }
});

function isValidUrl(string) {
    try {
        new URL(string);
        return true;
    } catch (_) {
        return false;
    }
}
