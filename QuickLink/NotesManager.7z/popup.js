document.addEventListener('DOMContentLoaded', function () {
    const addNoteButton = document.getElementById('addNoteButton');
    const findNoteButton = document.getElementById('findNoteButton');
    const listNotesButton = document.getElementById('listNotesButton');
    const status = document.getElementById('status');

    // Set focus to noteKeyword on load
    document.getElementById('noteKeyword').focus();

    addNoteButton.addEventListener('click', function () {
        const noteKeyword = document.getElementById('noteKeyword').value;
        const noteText = document.getElementById('noteText').value;
        const isUrl = document.getElementById('isUrlCheckbox').checked;
        const note = { keyword: noteKeyword, text: noteText, isUrl: isUrl };
        saveToIndexedDB(note);
        status.textContent = 'Note saved!';
        setTimeout(() => {
            status.textContent = '';
        }, 2000);
    });

    findNoteButton.addEventListener('click', function () {
        const noteKeyword = document.getElementById('noteKeyword').value;
        retrieveNoteFromIndexedDB(noteKeyword, function(note) {
            if (note) {
                document.getElementById('noteText').value = note.text;
                status.textContent = 'Note retrieved!';
                // Copy note to clipboard
                navigator.clipboard.writeText(note.text).then(() => {
                    console.log('Note copied to clipboard');
                }).catch(err => {
                    console.error('Could not copy text: ', err);
                });
            } else {
                status.textContent = 'Note not found or error retrieving note.';
            }
            setTimeout(() => {
                status.textContent = '';
            }, 2000);
        });
    });

    listNotesButton.addEventListener('click', function() {
        chrome.tabs.create({ url: chrome.runtime.getURL('list.html') });
    });

    function saveToIndexedDB(note) {
        const dbName = 'notesDB';
        const dbVersion = 1;
        const storeName = 'notesStore';

        const request = indexedDB.open(dbName, dbVersion);

        request.onerror = function (event) {
            console.error('IndexedDB error: ', event.target.errorCode);
        };

        request.onupgradeneeded = function (event) {
            const db = event.target.result;
            const objectStore = db.createObjectStore(storeName, { keyPath: 'id', autoIncrement: true });
            objectStore.createIndex('keyword', 'keyword', { unique: false });
            objectStore.createIndex('text', 'text', { unique: false });
            objectStore.createIndex('isUrl', 'isUrl', { unique: false }); // Add index for isUrl
        };

        request.onsuccess = function (event) {
            const db = event.target.result;
            const transaction = db.transaction([storeName], 'readwrite');
            const objectStore = transaction.objectStore(storeName);
            const newItem = { keyword: note.keyword, text: note.text, isUrl: note.isUrl, timestamp: new Date() };
            objectStore.add(newItem);
            console.log('Note saved to IndexedDB:', newItem);
        };
    }

    document.getElementById('noteKeyword').addEventListener('keypress', function (e) {
        if (e.key === 'Enter') {
            findNoteButton.click();
        }
    });
});

function retrieveNoteFromIndexedDB(keyword, callback) {
    const dbName = 'notesDB';
    const request = indexedDB.open(dbName);

    request.onerror = function(event) {
        console.error('IndexedDB error:', event.target.errorCode);
        callback(null);
    };

    request.onsuccess = function(event) {
        const db = event.target.result;
        const transaction = db.transaction(['notesStore'], 'readonly');
        const objectStore = transaction.objectStore('notesStore');
        const index = objectStore.index('keyword');

        const getRequest = index.get(keyword);

        getRequest.onsuccess = function(event) {
            const note = event.target.result;
            callback(note);
        };

        getRequest.onerror = function(event) {
            console.error('Error retrieving note:', event.target.error);
            callback(null);
        };
    };
}
